void RoofControl(float temp, int humidVal, int rainval, byte hour, byte minute) {
  static byte openMinute = 0;  // הדקה שבה נפתח הגג
  
  // תנאים לפתיחה - 
  // 1. חם מדי (>28°C) או לח מדי (>3000)
  // 2. לא יורד גשם
  // 3. שעות יום (10-18)
  // 4. לא קר מדי (>15°C)
  
  if (!roofOpen && ((temp > 28) || (humidVal > 3000)) && (rainval > 1000) && (hour >= 10 && hour < 18) && (temp > 15)) {
  //בודקים שהגג לא פתוח כבר ואו שהטמפ׳ גבוהה מ28 מעלות או שהלחות גבוהה מ3000 ושאין גשם ושאנחנו במהלך היום ושהטמפ׳ גבוהה מ15 מעלות  

    RoofSwitch(true); //אם כן פותחים את הגג
    roofOpen = true; //מעדכנים את דגל הגג שהוא פתוח
    openMinute = minute;  // שומרים את הדקה של הפתיחה
    Serial.print("Roof opened at "); //מדפיסים למוניטור את שעת פתיחת הגג
    Serial.print(hour);
    Serial.print(":");
    Serial.println(minute);
  }
  
  // תנאים לסגירה - 
  // 1. עברה דקה אחת מאז הפתיחה
  // 2. או מתחיל לרדת גשם (חירום)
  // 3. או שעות לילה (חירום)
  
  if (roofOpen) { //בודקים אם הגג פתוח
    byte minutesPassed; //מגדירים משתנה שיכיל כמה זמן עבר מפתיחת הגג
    if (minute >= openMinute) { //אם הדקה הנוכחית גדולה מהדקה בה נפתח הגג
      minutesPassed = minute - openMinute; //אז המשתנה מקבל את ההפרש שלהם
    } 
    else {
      minutesPassed = (60 - openMinute) + minute;  //אחרת, אם היה מעבר שעה מעדכנים את נוסחאת ההפרש
    }
    
    // סגירה אחרי דקה
    if (minutesPassed >= 1) { //אם עברה דקה מפתיחת הגג
      RoofSwitch(false); //סוגרים את הגג
      roofOpen = false; //מעדכנים את דגל הגג שהגג סגור
      Serial.print("Roof closed: "); //מדפיסים במוניטור את  שעת סגירת הגג
      Serial.print(hour);
      Serial.print(":");
      Serial.print(minute);
    }

    // סגירה חירום - גשם או לילה
    else if ((rainval < 1000) || (hour >= 18 || hour < 10)) { 
    //אם יש גשם או שאנחנו כבר אחרי השעות בהן הגג יכול להפתח

      RoofSwitch(false); //סוגרים את הגג
      roofOpen = false; //מעדכנים את דגל הגג שהוא סגור
      Serial.println("Roof closed - emergency (rain/night)"); //מדפיסים במוניטור שהיה מצב חירום או גשם או שמאוחר
    }
  }
}
