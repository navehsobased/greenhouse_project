void RTCtime() {
  DateTime now = rtc.now(); //משתנה זמני now שמאחסן את הזמן הנוכחי מאובייקט datetime
  second = now.second(); //הוצאת השניות
  minute =now.minute(); //הוצאת הדקות
  hour = now.hour(); //הוצאת השעות
}