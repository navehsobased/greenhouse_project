int rainRead() { //פונקציה קריאה מחיישן הגשם
  rainval = analogRead(rainPin); //קורא ערך אנלוגי מהדק 36
  return(rainval); //מחזיר את הערך של החיישן
}