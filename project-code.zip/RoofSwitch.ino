void RoofSwitch(bool openToken) {
  if (openToken) { //אם רוצים לפתוח את הגג
    // פתיחת הגג
    dutyCycle = 200; //מעדכנים את זמן מחזור הפעולה ל200
    Serial.println("Opening roof..."); //מדפיסים במוניטור שהגג נפתח
    ledcWrite(enable1Pin, dutyCycle); //הפעלת pwm עם זמן מחזור הפעולה על הדק ena1
    digitalWrite(motor1Pin1, LOW); //in1 כבוי
    digitalWrite(motor1Pin2, HIGH); //in2 דלוק - פתיחת הגג
  } 

  else {
    // סגירת הגג
    dutyCycle = 150; //מעדכנים את זמן מזחרו הפעולה ל150
    Serial.println("Closing roof..."); //מדפיסים במוניטור שהגג נסגר
    ledcWrite(enable1Pin, dutyCycle); //מפעילים pwm עם זמן מזחרו הפעולה על הדק ena1
    digitalWrite(motor1Pin1, HIGH); //in1 דלוק
    digitalWrite(motor1Pin2, LOW); //in2 כבוי - סגירת הגג
  }
}