int LDRread () { //פונקציית קריאה מחיישן LDR
  LDRval = analogRead(LDRpin); //קורא ערך אנלוגי מהדק 35 ושומר אותו במשתנה LDRval
  return (LDRval); //מחזיר לתוכנית הראשית את הערך במשתנה
}