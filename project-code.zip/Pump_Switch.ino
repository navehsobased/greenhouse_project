void PumpSwitch(int humidVal, int rainval, float tempv, byte hour, byte minute) {
  
  if ((humidVal < 2700) && ((hour == 8) || (hour == 22)) && (minute == 0) && (tempv > 10) && !pumpStarted) {
  //בודקים אם לחות האדמה נמוכה מ2700 (יבשה) ומתזמנים את השקייה לפעמיים ביום בשעה 8 ובשעה 22 ובדוקים שהטמפ׳ גבוהה מ10 מעלות ושהמשאבה לא דלוקה כבר
    
    if (rainval < 1000) { //בודקים אם יורד גשם
      Serial.println("Watering with rain"); //מדפיסים במוניטור שמשקים עם גשם
      RoofSwitch(true);  // פתיחת הגג
      pumpStarted = true; //מעדכנים את דגל המשאבה שהיא פועלת (למען הסגירה)
    }
    else {
      Serial.println("watering with pump"); //אחרת אם אין גשם מדפיסים במוניטור שמשקים עם המשאבה
      digitalWrite(PumpPin, HIGH); //מדליקים את המשאבה
      pumpStarted = true; //מעדכנים את הדגל של המשאבה שהיא דולק
    }
  }
  
  if (pumpStarted && ((hour == 8) || (hour == 22)) && (minute == 1)) { //בודקים אם המשאבה דולקת ועברה דקה מתחילת התנאי הקודם
    digitalWrite(PumpPin, LOW); //אם כן מכבים את המשאבה
    RoofSwitch(false);  // סגור את הגג
    pumpStarted = false; //מעדכנים את דגל המשאבה שהיא כבויה
    Serial.println("pump turned off"); //מדפיסים במוניטור שהמשאבה כבויה
  }
  
  // איפוס בחצות
  if (hour == 0 && minute == 0) { //בודקים אם חצות
    digitalWrite(PumpPin, LOW); //מכבים את המשאבה
    RoofSwitch(false); //סוגרים את הגג
    pumpStarted = false; //מאפסים את הדגל
  }
}