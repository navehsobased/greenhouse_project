void LCDscreen(bool LEDtoken, bool BulbToken, bool FanToken, int ldrv, int rainv, int humidv, float tempv, byte hour, byte minute, byte second) { //פונקציית הצגת הנתנוים על המסך
  lcd.clear(); //מאפסים את המסך

  //-------------------------
  lcd.setCursor(0, 0); //ממקמים את הסמן ב0,0
  lcd.print("Light:"); //מדפיסים את ערך האור
  lcd.print(ldrv);

  lcd.print(" | "); //מדפיסים מחיצה

  if (LEDtoken) { //בודקים אם הלדים דלוקים
    lcd.print("Led:on "); //אם כן מדפיסים שכן
  }
  else { 
    lcd.print("Led:off"); //אם לא מדפיסים שלא
  }
  //-------------------------
  lcd.setCursor(0, 1); //ממקמים את הסמן ב0,1
  lcd.print("Temp:"); //מדפיסים את ערך הטמפרטורה
  lcd.print(tempv, 1);
  
  lcd.print(" | "); //מדפיסים מחיצה

  if (rainv < 1000) { //בודקים אם יורד גשם
    lcd.print("Rain:yes"); //אם כן מדפיסים שכן
  }
  else {
    lcd.print("Rain:no "); //אם לא מדפיסים שלא
  }
  //-------------------------
  lcd.setCursor(0, 2); //ממקמים את הסמן ב0,2
  lcd.print("Humid:"); //מדפיסים את ערך חיישן הלחות
  lcd.print(humidv);

  lcd.print(" | "); //מדפיסים מחיצה

  if (FanToken) { //בודקים אם המאוורר דלוק
    lcd.print("Fan:on "); //אם כן מדפיסים שכן
  }
  else {
    lcd.print("Fan:off"); //אם לא מדפיסים שלא
  }
  //-------------------------
  lcd.setCursor(0, 3); //ממקמים את הסמן ב0,3

  if (BulbToken) { //בוקים אם המנורה דלוקה
    lcd.print("Bulb:on "); //אם כן מדפיסים שכן
  }
  else {
    lcd.print("Bulb:off"); //אם לא מדפיסים שלא
  }

  lcd.print(" | "); //מדפיסים מחיצה

  lcd.print(hour); //מדפיסים את השעה הנוכחית
  lcd.print(":");
  lcd.print(minute);
  lcd.print(":");
  lcd.print(second);
  //-------------------------
}