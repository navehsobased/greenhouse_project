void BulbSwitch(float tempval) { //פונקצייה להדלקת נורת חימום
  if (tempval < 23.0) { //בודקים אם הטמפרטורה נמוכה מ23 מעלות
    digitalWrite(bulbPin, LOW); //אם כן מדליקים את המנורה
    BulbToken = true; //מעדכנים את דגל המנורה שהיא דלוקה
  }
  else {
    digitalWrite(bulbPin, HIGH); //אחרת מכבים את המנורה
    BulbToken = false; //מעדכנים את דגל המנורה שהיא כבויה
  }
}