void LEDswitch(int light, byte hour, byte minute) { //פונקציה של הדלקה וכיבוי האורות לפי ldr
  if ((light < 1800) && ((hour >= 6) && (hour < 22))) { //בודקים אם יש מחסור באור טבעי במהלך היום
    for (int i = 0; i < NUM_LEDS; i++){ //לולאה שרצה על כל הלדים (16)
    strip.setPixelColor(i,strip.Color(180, 0, 255)); //מגדירים כל פיקסל ברצועה לצבע סגול
    }
    strip.show(); //מציגים את הצבע בלד
    LEDtoken = true; //מעדכנים את דגל אלד שהם דלוקים
  }
  else {
    for (int i = 0; i < NUM_LEDS; i++){ //אחרת מריצים לולאה שעוברת על כל הלדים
    strip.setPixelColor(i,strip.Color(0, 0, 0)); //ומכבה את כולם
    }
    strip.show(); //מציגים את הצבע (כבוי)
    LEDtoken = false; //מעדכנים את דגל הלד לכבוי
  }
} 