int humidRead () { //קריאה מחיישן לחות האדמה
  humidVal = analogRead(HumidPin); //קורא את הערך האנלוגי מהדק 33
  return (humidVal); //מחזיר את הערך לתוכנית הראשית
}