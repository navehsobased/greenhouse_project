void fanSwitch(float tempval) { //פונקציית הדלקה וכיבוי המאוורר
  if (tempval > 26.0) { //בודקים אם הטמפרטורה נמוכה מ26 מעלות
    digitalWrite(fanPin, LOW); //אם כן מדליקים את המאוורר
    FanToken = true; //מעדכים את דגל המאוורר לדלוק
  }
  else {
    digitalWrite(fanPin, HIGH); //אחרת המאוורר כבוי/נכבה 
    FanToken = false; //מעדכנים את דגל המאוורר לכבוי
  }
}